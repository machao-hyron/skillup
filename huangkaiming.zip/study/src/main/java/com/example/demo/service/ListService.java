package com.example.demo.service;

		import com.example.demo.entity.TUserInfo;

		import java.util.List;

public interface ListService {
	/**
	 * 信息
	 */
	List<TUserInfo> init();
}